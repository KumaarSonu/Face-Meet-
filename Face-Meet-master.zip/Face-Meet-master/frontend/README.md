**Frontend Folder**
- All Frontend Activity